test = {
'name': "Question",
'points': 1,
'suites': [
{
'cases': [

{
'code': r"""
>>> pOf2Heads(1) == 1
True
>>> pOf2Heads(0) == 0
True
>>> all([0<=pOf2Heads(x)<=1 for x in np.linspace(0,1,20)])
True

""",
'hidden': False,
'locked': False
}

],
'scored': True,
'setup': '',
'teardown': '',
'type': 'doctest'
}
]
}
